<!DOCTYPE html>
<html lang="en" class="h-100">

<?php
$folder = "/public/";
if(url('/') == "http://127.0.0.1:8004"){
    $folder = "";
}
?>

<head>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="keywords" content="admin, dashboard" />
	<meta name="author" content="DexignZone" />
	<meta name="robots" content="index, follow" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Microfinance Trade - The best global trading platform" />
	<meta property="og:title" content="Microfinance Trade - The best global trading platform" />
	<meta property="og:description" content="Microfinance Trade - The best global trading platform" />
	<meta property="og:image" content="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>images/logo.png"/>
	<meta name="format-detection" content="telephone=no">
    <title>SignIn - Microfinance Trade</title>

    <link rel="shortcut icon" href="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>images/favicon.png" type="image/x-icon">
	<!-- <link href="<?php echo e(url('/')); ?>/dashboard_files/vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet"> -->
    <link href="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>dashboard_files/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>css/custom-bootstrap-margin-padding.css" type="text/css"/>

</head>

<body class="vh-100">

    <?php $name = Route::currentRouteName(); ?>
    <input type="hidden" value="<?php echo e($name); ?>" id="routeName">
    <input type="text" value="<?php echo e(url('/')); ?>" id="url" style="display:none">
    <input type="hidden" value="<?php echo e(csrf_token()); ?>" id="txt_token">

    <div class="alert alert-danger alertMsg align-items-center">
        <i class="fa fa-times"></i>
    </div>

    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-lg-5 col-md-9 pl-xs-5 pr-xs-5">
                    <div class="authincation-content btn-round">
                        <div class="row no-gutters">
                            <div class="col-xl-12 pl-5 pr-5 pl-xs-0 pr-xs-0">
                                <div class="auth-form">
									<div class="text-center mb-3">
										<a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>images/logo.png" style="width:180px" alt=""></a>
									</div>
                                    <h4 class="text-center mb-4" style="color:#b87435">Login to your admin account</h4>
                                    <form action="#">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-group">
                                            <!-- <label class="mb-1"><strong>Email</strong></label> -->
                                            <input type="email" class="form-control btn-round" placeholder="Enter your username" required="" id="txtemail_adm" style="font-size:16px">
                                        </div>

                                        <div class="form-group">
                                            <input type="password" class="form-control btn-round" placeholder="Enter your password" required="" id="txtpass_adm" style="font-size:16px">
                                        </div>

                                        <div class="form-row d-flex justify-content-between mt-4 mb-2">
                                            <div class="form-group">
                                               <div class="form-check custom-checkbox ms-1">

													<input type="checkbox" class="form-check-input" name="remember_adm" id="remember_adm" <?php echo e(old('remember') ? 'checked' : ''); ?> value="0">

													<label class="form-check-label" for="remember_adm" style="font-size:14px; color:#333;position:relative;top:3px;">Remember my details</label>
												</div>
                                            </div>
                                            <!-- <div class="form-group">
                                                <a href="page-forgot-password.html">Forgot Password?</a>
                                            </div> -->
                                        </div>
                                        <div class="text-center">
                                            <button type="button" class="btn btn-primary btn-block cmd_signin_adm">SIGN ME IN</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>dashboard_files/vendor/global/global.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>dashboard_files/js/custom.min.js"></script>
    
	<script src="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>js/jquery.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>js/jscripts.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\bitcoin_exchange\resources\views/auth/shield/login1.blade.php ENDPATH**/ ?>