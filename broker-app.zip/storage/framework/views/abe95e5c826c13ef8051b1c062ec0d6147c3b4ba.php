<!DOCTYPE html>
<html lang="en" xml:lang="en">


<head>       
    <meta charset="UTF-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="shortcut icon" href="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>images/favicon.png" type="image/x-icon">

    <link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800" rel="stylesheet">
    <title>Microfinance Trade</title>
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>css/font-awesome.min.css" type="text/css"/>
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>css/bootstrap.css" type="text/css"/>
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>css/animate.css" type="text/css"/>
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>css/owl.carousel.min.css" type="text/css"/>
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>css/slick.css" type="text/css"/>

    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>css/style.css" type="text/css"/>

    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>css/responsive.css" type="text/css"/>

    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>css/custom-bootstrap-margin-padding.css" type="text/css"/>

    
    <link rel="manifest" href="path-to_file/manifest.json">
    
     <!-- Stylesheets End -->
    <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
    <!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
    
</head>
<body>
    <input type="hidden" value="<?php echo e(csrf_token()); ?>" id="txt_token">
    <input type="text" value="<?php echo e(url('/')); ?>" id="url" style="display:none">

    <?php $name = Route::currentRouteName(); ?>
    <input type="hidden" value="<?php echo e($name); ?>" id="routeName">

    <div class="wrapper" id="top">
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 logo">
                        <a href="#" title="Microfinance Trade">
                            <img class="light" src="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>images/logo.png" alt="Microfinance Trade">
                            <img class="dark" src="<?php echo e(url('/')); ?>/<?php echo e($folder); ?>images/logo.png" alt="Microfinance Trade">
                        </a>
                    </div>



                    
                    <div class="topnav" id="myTopnav">
                        <a href="<?php echo e(url('/')); ?>#home" class="active">Home</a>
                        <a href="<?php echo e(url('/')); ?>#about">About</a>
                        <div class="dropdown1">
                            <button class="dropbtn1">Trading 
                            <i class="fa fa-caret-down"></i>
                            </button>
                            <div class="dropdown-content1">
                            <a href="<?php echo e(url('trading/forex-widgets')); ?>">MFT Forex Widgets</a>
                            <a href="<?php echo e(url('trading/continuous-cfds')); ?>">Continuous CFDs</a>
                            <a href="<?php echo e(url('trading/economic-calendar')); ?>">MFT Economic Calendar</a>
                            <a href="<?php echo e(url('trading/bitcoin')); ?>">Bitcoin</a>
                            </div>
                        </div> 

                        <div class="dropdown1">
                            <button class="dropbtn1 dropbtn2">Our Innovations 
                            <i class="fa fa-caret-down"></i>
                            </button>
                            <div class="dropdown-content1">
                            <a href="<?php echo e(url('trading/money-management')); ?>">Money Management Limits to Trade</a>
                            <a href="<?php echo e(url('trading/asset-equity')); ?>">Available Assets Equity</a>
                            </div>
                        </div> 

                        <a href="<?php echo e(url('/')); ?>#home">Analytics</a>
                        <a href="<?php echo e(url('/')); ?>#faq">FAQ</a>
                        <a href="<?php echo e(route('contact')); ?>">Contact Us</a>

                        <?php
                        $fullname = @$users->fullname;
                        $fname = ucfirst(explode(" ", $fullname)[0]);
                        ?>

                        <?php if(auth()->guard('user')->check()): ?>
                            <a href="<?php echo e(route('dashboard')); ?>" style="color:#f0931e;"><?php echo e($fname); ?></a>
                        <?php endif; ?>

                        <?php if(auth()->guard('user')->guest()): ?>
                            <a class="nav-btn" href="<?php echo e(route('signin')); ?>">Sign In</a>
                        <?php endif; ?>
                        
                        <a href="javascript:void(0);" style="font-size:15px;" class="icon myFunction" >&#9776;</a>
                    </div>


                    
                    
                </div>
            </div>
        </header><?php /**PATH C:\xampp\htdocs\bitcoin_exchange\resources\views/header.blade.php ENDPATH**/ ?>