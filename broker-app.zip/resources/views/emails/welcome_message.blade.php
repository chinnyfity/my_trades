
<div class="container" style="padding: 1rem; background: #f5f5f5;">
    <p>Good Morning XYZ!</p>
    <p>
        Welcome to Laravel. This is a demo of sending emails through
        the Mailgun email service.
    </p>
</div>